import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:easyenglish/pages/signup_page.dart';
import 'package:easyenglish/pages/level_select_page.dart';
import 'firebase_options.dart'; // 👈 꼭 추가하세요!

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    // ✅ 수정된 부분: 옵션값 추가
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    debugPrint('✅ Firebase 초기화 완료');
  } catch (e) {
    debugPrint('❌ Firebase 초기화 실패: $e');
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EasyEnglish',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.hasData) {
            // ✅ 수정된 부분: 실제 UID를 전달합니다.
            debugPrint('✅ 로그인 성공: ${snapshot.data!.uid}');
            return LevelSelectPage(
              userId: snapshot.data!.uid, // 빈 칸 대신 실제 ID 전달
            );
          } else {
            debugPrint('❌ 로그인 정보 없음: SignupPage로 이동');
            return const SignupPage();
          }
        },
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
