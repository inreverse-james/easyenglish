// lib/services/ranking_service.dart

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:easyenglish/models/ranking_data.dart';
import 'package:firebase_auth/firebase_auth.dart'; // 1. Firebase Auth 패키지 추가

class RankingService {
  // 2. 모든 유저가 함께 쓰던 키 대신, 사용자별 키를 만들기 위한 기본(base) 키로 변경
  static const String _rankingKeyBase = 'user_rankings';

  // 3. 현재 로그인된 사용자의 고유 ID(UID)를 가져오는 메서드 추가
  Future<String?> getUserId() async {
    return FirebaseAuth.instance.currentUser?.uid;
  }

  // 4. 로컬 저장소 대신 Firebase 프로필에서 사용자 이름을 가져오도록 수정
  Future<String?> getUserName() async {
    final user = FirebaseAuth.instance.currentUser;
    // Firebase 프로필에 설정된 이름(displayName)을 가져오고, 없으면 이메일을 사용
    return user?.displayName ?? user?.email;
  }

  /// 현재 사용자의 ID를 기반으로 고유한 랭킹 저장 키를 생성합니다.
  Future<String?> _getUserSpecificRankingKey() async {
    final userId = await getUserId();
    if (userId == null) return null; // 로그인하지 않은 경우 null 반환
    return '${_rankingKeyBase}_$userId';
  }

  /// 현재 로그인된 사용자의 랭킹 목록을 가져옵니다.
  Future<List<RankingData>> getRankings() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? userRankingKey = await _getUserSpecificRankingKey();

    // 로그인 상태가 아니면 빈 목록 반환
    if (userRankingKey == null) {
      return [];
    }

    final List<String> rankingJsonList =
        prefs.getStringList(userRankingKey) ?? [];

    return rankingJsonList
        .map((jsonString) => RankingData.fromJson(
            json.decode(jsonString) as Map<String, dynamic>))
        .toList();
  }

  /// 현재 로그인된 사용자의 랭킹을 추가합니다.
  Future<void> addRanking(RankingData ranking) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? userRankingKey = await _getUserSpecificRankingKey();

    // 로그인 상태가 아니면 저장하지 않음
    if (userRankingKey == null) {
      return;
    }

    // getRankings()가 이미 현재 사용자 랭킹만 가져오므로 그대로 사용
    final List<RankingData> rankings = await getRankings();
    rankings.add(ranking);

    final List<String> rankingJsonList =
        rankings.map((r) => json.encode(r.toJson())).toList();
    await prefs.setStringList(userRankingKey, rankingJsonList);
  }

  /// 현재 로그인된 사용자의 모든 랭킹 기록을 삭제합니다.
  Future<void> clearRankings() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? userRankingKey = await _getUserSpecificRankingKey();

    if (userRankingKey != null) {
      await prefs.remove(userRankingKey);
    }
  }

  // 5. setUserName 메서드는 삭제합니다.
  // 사용자 이름은 Firebase 프로필에서 직접 관리하는 것이 좋습니다.
  // (예: 별도의 '프로필 수정' 페이지에서 user.updateDisplayName() 호출)
}
