// lib/pages/word_study_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/word.dart';
import '../services/word_data_service.dart';
import 'package:easyenglish/pages/settings_page.dart';

class WordStudyPage extends StatefulWidget {
  final String level;

  const WordStudyPage({
    super.key,
    required this.level,
  });

  @override
  State<WordStudyPage> createState() => _WordStudyPageState();
}

class _WordStudyPageState extends State<WordStudyPage> {
  // Services
  final FlutterTts _tts = FlutterTts();
  final WordDataService _dataService = WordDataService();

  // Data
  List<Word> _wordList = [];
  bool _isLoading = true;
  String? _error;

  // Study state
  int _currentIndex = 0;
  bool _showMeaning = false;
  bool _alwaysShowMeaning = false;

  // Bookmark: we only keep the last saved index for this level
  int? _savedBookmarkIndex; // cached in memory for quick compare

  // TTS state
  bool _isSpeaking = false;

  // Quick-move
  int _quickMoveStep = 10;
  final List<int> _quickMoveOptions = const [10, 50, 100];

  @override
  void initState() {
    super.initState();
    _fetchWords();
    _initTts();
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  // ------------------------------ Data ------------------------------
  Future<void> _fetchWords() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      if (!mounted) return;

      // WordDataService를 통해 데이터 가져오기
      final list = await _dataService.getWordsForLevel(widget.level);

      if (!mounted) return;

      if (list.isEmpty) {
        setState(() {
          _wordList = [];
          _isLoading = false;
          _error = '단어 데이터가 존재하지 않습니다.';
        });
        return;
      }

      setState(() {
        _wordList = list;
        _isLoading = false;
      });

      // Load bookmark only after list is ready
      await _loadBookmark();

      // Bookmark가 범위를 벗어나는 경우 조정
      if (_savedBookmarkIndex != null &&
          (_savedBookmarkIndex! < 0 ||
              _savedBookmarkIndex! >= _wordList.length)) {
        setState(() {
          _currentIndex = 0;
          _savedBookmarkIndex = null;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '데이터를 불러오는 중 오류가 발생했습니다.\n$e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadBookmark() async {
    final prefs = await SharedPreferences.getInstance();
    final key = '${widget.level}_bookmark';
    final idx = prefs.getInt(key);
    if (!mounted) return;
    if (idx != null &&
        _wordList.isNotEmpty &&
        idx >= 0 &&
        idx < _wordList.length) {
      setState(() {
        _savedBookmarkIndex = idx;
        _currentIndex = idx; // jump to last saved word
      });
    }
  }

  Future<void> _saveBookmark() async {
    if (_wordList.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final key = '${widget.level}_bookmark';

    // 현재 단어가 이미 책갈피에 저장되어 있는지 확인
    if (_savedBookmarkIndex == _currentIndex) {
      // 이미 저장되어 있다면 제거
      await prefs.remove(key);
      if (!mounted) return;
      setState(() {
        _savedBookmarkIndex = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('책갈피가 해제되었습니다.')),
      );
    } else {
      // 저장되어 있지 않다면 현재 인덱스를 저장
      await prefs.setInt(key, _currentIndex);
      if (!mounted) return;
      setState(() {
        _savedBookmarkIndex = _currentIndex;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('현재 단어가 책갈피에 저장되었습니다.')),
      );
    }
  }

  // ------------------------------ TTS ------------------------------
  Future<void> _initTts() async {
    try {
      // Handlers
      _tts.setStartHandler(() {
        if (mounted) setState(() => _isSpeaking = true);
      });
      _tts.setCompletionHandler(() {
        if (mounted) setState(() => _isSpeaking = false);
      });
      _tts.setCancelHandler(() {
        if (mounted) setState(() => _isSpeaking = false);
      });
      _tts.setErrorHandler((msg) {
        if (mounted) setState(() => _isSpeaking = false);
        debugPrint('TTS error: $msg');
      });

      // Try a few common English locales
      final langs = ['en-US', 'en-GB', 'en-AU', 'en'];
      for (final l in langs) {
        try {
          await _tts.setLanguage(l);
          break;
        } catch (_) {}
      }

      await _tts.awaitSpeakCompletion(true);
      await _tts.setSpeechRate(0.3);
      await _tts.setPitch(1.0);
      await _tts.setVolume(1.0);
    } catch (e) {
      debugPrint('TTS init failed: $e');
    }
  }

  String _preprocessText(String s) {
    return s
        .replaceAll(RegExp(r'\[.*?\]'), '')
        .replaceAll(RegExp(r'\(.*?\)'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  Future<void> _speak(String text) async {
    if (_isSpeaking) {
      try {
        await _tts.stop();
      } catch (_) {}
    }
    try {
      final t = _preprocessText(text);
      await _tts.speak(t);
    } catch (e) {
      debugPrint('Speak failed: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('음성 재생 중 오류가 발생했습니다.')),
      );
    }
  }

  // ------------------------------ Controls ------------------------------
  void _nextWord() {
    if (_wordList.isEmpty) return;
    setState(() {
      _currentIndex = (_currentIndex + 1) % _wordList.length;
      if (!_alwaysShowMeaning) _showMeaning = false;
    });
  }

  void _previousWord() {
    if (_wordList.isEmpty) return;
    setState(() {
      _currentIndex = (_currentIndex - 1 + _wordList.length) % _wordList.length;
      if (!_alwaysShowMeaning) _showMeaning = false;
    });
  }

  void _quickMoveForward() {
    if (_wordList.isEmpty) return;
    setState(() {
      _currentIndex = (_currentIndex + _quickMoveStep) % _wordList.length;
      if (!_alwaysShowMeaning) _showMeaning = false;
    });
  }

  void _quickMoveBackward() {
    if (_wordList.isEmpty) return;
    setState(() {
      _currentIndex = (_currentIndex - _quickMoveStep + _wordList.length) %
          _wordList.length;
      if (!_alwaysShowMeaning) _showMeaning = false;
    });
  }

  void _toggleMeaning() {
    setState(() => _showMeaning = !_showMeaning);
  }

  void _toggleAlwaysShowMeaning() {
    setState(() {
      _alwaysShowMeaning = !_alwaysShowMeaning;
      if (_alwaysShowMeaning) _showMeaning = true;
    });
  }

  // ------------------------- UI Helper -------------------------
  // 예문 내 단어를 강조하는 위젯 생성 함수
  Widget _buildHighlightedText({
    required String fullText,
    required TextStyle defaultStyle,
    required Set<String> subjectWords,
    required Set<String> verbWords,
  }) {
    if (fullText.isEmpty) {
      return Text(fullText, style: defaultStyle, textAlign: TextAlign.center);
    }

    final allTargets = {
      ...subjectWords,
      ...verbWords,
    }
        .where((w) => w.isNotEmpty)
        .map((w) => r'\b' + RegExp.escape(w) + r'\b')
        .join('|');

    if (allTargets.isEmpty) {
      return Text(fullText, style: defaultStyle, textAlign: TextAlign.center);
    }

    final pattern = RegExp('($allTargets)', caseSensitive: false);
    final List<InlineSpan> spans = [];

    fullText.splitMapJoin(
      pattern,
      onMatch: (m) {
        final originalWord = m.group(0)!;
        final word = originalWord.toLowerCase();

        TextStyle style = defaultStyle.copyWith(fontWeight: FontWeight.bold);

        final isSubject = subjectWords.contains(word);
        final isVerb = verbWords.contains(word);

        // 명사(주어)는 주황색 밑줄
        if (isSubject) {
          style = style.copyWith(
              backgroundColor: const Color.fromARGB(255, 255, 226, 221));
        }

        // 동사는 연한 노란색 배경
        if (isVerb) {
          style = style.copyWith(
              backgroundColor: const Color.fromARGB(255, 240, 255, 185));
        }

        spans.add(TextSpan(text: originalWord, style: style));
        return '';
      },
      onNonMatch: (n) {
        spans.add(TextSpan(text: n, style: defaultStyle));
        return '';
      },
    );

    return RichText(
      text: TextSpan(children: spans),
      textAlign: TextAlign.center,
    );
  }

  // ------------------------------ UI ------------------------------
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildScaffold(const Center(child: CircularProgressIndicator()));
    }
    if (_error != null) {
      return _buildScaffold(Center(child: Text('오류: $_error')));
    }
    if (_wordList.isEmpty) {
      return _buildScaffold(const Center(child: Text('단어 목록이 비어 있습니다.')));
    }

    final w = _wordList[_currentIndex];
    final showMeaning = _showMeaning || _alwaysShowMeaning;
    final isBookmarked = _savedBookmarkIndex == _currentIndex;

    // subjectWords와 verbWords 설정
    Set<String> subjectWords = {};
    if (w.subject != null) {
      subjectWords.add(w.subject!.toLowerCase());
    }

    Set<String> verbWords = {};
    if (w.verb != null) {
      verbWords.add(w.verb!.toLowerCase());
    }

    return _buildScaffold(
      Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const SizedBox(height: 24),

              // Top: progress + always-show switch
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${widget.level} (${_currentIndex + 1}/${_wordList.length})',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[700],
                      ),
                    ),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        '뜻 항상 보기',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Switch(
                        value: _alwaysShowMeaning,
                        onChanged: (value) => _toggleAlwaysShowMeaning(),
                        activeThumbColor: Colors.grey,
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 12),

              // Card (stack to overlay bookmark button)
              SizedBox(
                height: 350,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
                        child: Column(
                          children: [
                            // Word content
                            Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          w.word,
                                          style: const TextStyle(
                                              fontSize: 28,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF2B5CB1)),
                                        ),
                                        const SizedBox(width: 8),
                                        InkWell(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          onTap: () => _speak(w.word),
                                          child: const Padding(
                                            padding: EdgeInsets.all(6),
                                            child: Icon(Icons.volume_up,
                                                color: Color(0xFF6C88B7),
                                                size: 22),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      '[ ${w.pronunciation.replaceAll(RegExp(r'\s'), '')} ]',
                                      style: const TextStyle(
                                        fontSize: 20,
                                        color: Colors.blueGrey,
                                        fontStyle: FontStyle.normal,
                                      ),
                                    ),
                                    const SizedBox(height: 16),
                                    AnimatedSwitcher(
                                      duration:
                                          const Duration(milliseconds: 200),
                                      child: showMeaning
                                          ? Column(
                                              key: const ValueKey('meaning'),
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '(${w.partOfSpeech})',
                                                      style: const TextStyle(
                                                        fontSize: 18,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: Colors.blueGrey,
                                                      ),
                                                    ),
                                                    const SizedBox(width: 8),
                                                    Flexible(
                                                      child: Text(
                                                        w.meaning,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: const TextStyle(
                                                          fontSize: 20,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.black87,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                if (w.example.isNotEmpty) ...[
                                                  const SizedBox(height: 14),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      Expanded(
                                                        child:
                                                            _buildHighlightedText(
                                                          fullText: w.example,
                                                          subjectWords: {
                                                            w.subject
                                                                    ?.toLowerCase() ??
                                                                '',
                                                          },
                                                          verbWords: {
                                                            w.verb?.toLowerCase() ??
                                                                ''
                                                          },
                                                          defaultStyle:
                                                              const TextStyle(
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            fontStyle: FontStyle
                                                                .normal,
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(width: 6),
                                                      InkWell(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(16),
                                                        onTap: () =>
                                                            _speak(w.example),
                                                        child: const Padding(
                                                          padding:
                                                              EdgeInsets.all(4),
                                                          child: Icon(
                                                              Icons.volume_up,
                                                              size: 22,
                                                              color: Color(
                                                                  0xFF6C88B7)),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  if (w.exampleMeaning
                                                      .isNotEmpty)
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 6),
                                                      child: Text(
                                                        w.exampleMeaning,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: const TextStyle(
                                                            fontSize: 16,
                                                            color: Colors
                                                                .blueGrey),
                                                      ),
                                                    ),
                                                ],
                                              ],
                                            )
                                          : const SizedBox.shrink(),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            // Bottom quick-move
                            Padding(
                              padding: const EdgeInsets.only(top: 8, bottom: 0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.fast_rewind,
                                        size: 22, color: Colors.grey),
                                    onPressed: _quickMoveBackward,
                                  ),
                                  DropdownButton<int>(
                                    value: _quickMoveStep,
                                    underline: const SizedBox.shrink(),
                                    style: const TextStyle(
                                        fontSize: 14, color: Colors.black87),
                                    items: _quickMoveOptions
                                        .map((v) => DropdownMenuItem<int>(
                                              value: v,
                                              child: Text('$v개씩'),
                                            ))
                                        .toList(),
                                    onChanged: (v) {
                                      if (v == null) return;
                                      setState(() => _quickMoveStep = v);
                                    },
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.fast_forward,
                                        size: 22, color: Colors.grey),
                                    onPressed: _quickMoveForward,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Bookmark button
                    Positioned(
                      top: -6,
                      left: -6,
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: _saveBookmark,
                          child: Padding(
                            padding: const EdgeInsets.all(6),
                            child: Icon(
                              isBookmarked
                                  ? Icons.bookmark
                                  : Icons.bookmark_border,
                              color: isBookmarked ? Colors.orange : Colors.grey,
                              size: 28,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Meaning toggle button
              SizedBox(
                width: 220,
                child: ElevatedButton(
                  onPressed: _alwaysShowMeaning ? null : _toggleMeaning,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _alwaysShowMeaning
                        ? Colors.grey
                        : const Color(0xFF6C88B7),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    _showMeaning ? '뜻 숨기기' : '뜻 보기',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _alwaysShowMeaning ? Colors.black54 : Colors.white,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Prev / Next
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  OutlinedButton(
                    onPressed: _previousWord,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF6C88B7),
                      side: const BorderSide(color: Color(0xFF6C88B7)),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('이전 단어',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  ElevatedButton(
                    onPressed: _nextWord,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6C88B7),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('다음 단어',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Scaffold _buildScaffold(Widget body) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.level} 단어 공부'),
        backgroundColor: const Color(0xFF6C88B7),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                    builder: (context) => const SettingsPage(
                          userId: '',
                        )),
              );
            },
          ),
        ],
      ),
      body: body,
    );
  }
}
