import 'package:flutter/material.dart';
import 'package:easyenglish/pages/level_select_page.dart';
import 'package:easyenglish/models/quiz_models.dart';
import 'package:easyenglish/pages/ranking_page.dart';

class QuizResultPage extends StatelessWidget {
  final List<WordQuizAnswer> quizAnswers;
  final int correctAnswers;
  final int totalQuestions;
  final List<String> levels;
  final String userId; // 생성자 매개변수로 userId를 받습니다.

  const QuizResultPage({
    super.key,
    required this.quizAnswers,
    required this.correctAnswers,
    required this.totalQuestions,
    required this.levels,
    required this.userId, // 매개변수 이름을 일치시킵니다.
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '시험 결과',
          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.black54),
          // 뒤로가기 버튼 동작을 pop으로 변경합니다.
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      backgroundColor: Colors.grey.shade50,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildSummaryCard(userId),
            const SizedBox(height: 12),
            _buildSectionTitle('문제 리뷰'),
            const SizedBox(height: 6),
            _buildSequentialReviewList(),
            const SizedBox(height: 12),
            _buildButtonRow(context),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard(String userId) {
    final double accuracy = (correctAnswers / totalQuestions) * 100;
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              '$userId님의 시험 결과',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildMetric('정확도', '${accuracy.toStringAsFixed(1)}%',
                    Colors.green.shade600),
                _buildMetric(
                    '정답', correctAnswers.toString(), Colors.blue.shade600),
                _buildMetric('오답', (totalQuestions - correctAnswers).toString(),
                    Colors.red.shade600),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetric(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 0),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: Colors.black87,
      ),
    );
  }

  Widget _buildSequentialReviewList() {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: quizAnswers.length,
          itemBuilder: (context, index) {
            final answer = quizAnswers[index];
            final questionNumber = index + 1;

            return Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                border: Border(
                  bottom: index < quizAnswers.length - 1
                      ? BorderSide(color: Colors.grey.shade200, width: 0.5)
                      : BorderSide.none,
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 34,
                    height: 18,
                    child: Stack(
                      children: [
                        Positioned(
                          left: 16,
                          child: Text(
                            '$questionNumber.',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        if (!answer.isCorrect)
                          Positioned(
                            top: -3,
                            left: 0,
                            child: Text(
                              '✗',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.red.shade600,
                              ),
                            ),
                          ),
                        if (answer.isCorrect)
                          Positioned(
                            top: -3,
                            left: 0,
                            child: Text(
                              '○',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Colors.blue.shade600,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        style: const TextStyle(
                          fontSize: 15,
                          color: Colors.black87,
                          height: 1.3,
                        ),
                        children: [
                          TextSpan(
                            text: answer.word.word,
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              backgroundColor: Colors.grey.shade200,
                              color: Colors.black87,
                            ),
                          ),
                          const TextSpan(text: ' - '),
                          TextSpan(
                            text: answer.selectedAnswer,
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: answer.isCorrect
                                  ? Colors.black87
                                  : Colors.red.shade600,
                            ),
                          ),
                          if (!answer.isCorrect) ...[
                            const TextSpan(
                              text: ' (정답: ',
                              style: TextStyle(color: Colors.grey),
                            ),
                            TextSpan(
                              text: answer.word.meaning,
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.green.shade700,
                              ),
                            ),
                            const TextSpan(
                              text: ')',
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildButtonRow(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _buildRankingButton(context)),
        const SizedBox(width: 10),
        Expanded(child: _buildHomeButton(context)),
      ],
    );
  }

  Widget _buildRankingButton(BuildContext context) {
    return SizedBox(
      height: 50,
      child: ElevatedButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => RankingPage(userId: userId),
            ),
          );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue.shade600,
          foregroundColor: Colors.white,
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: const Text(
          '랭킹 보기',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildHomeButton(BuildContext context) {
    return SizedBox(
      height: 50,
      child: ElevatedButton(
        onPressed: () {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(
                builder: (context) => LevelSelectPage(userId: userId)),
            (route) => false,
          );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 226, 167, 91),
          foregroundColor: Colors.white,
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: const Text(
          '홈으로 돌아가기',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
