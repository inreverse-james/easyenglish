import 'package:flutter/material.dart';
import 'package:easyenglish/services/word_data_service.dart';
import 'package:easyenglish/services/ranking_service.dart';
import 'package:easyenglish/models/word.dart';
import 'package:easyenglish/models/ranking_data.dart';
import 'package:easyenglish/pages/level_select_page.dart';
import 'package:easyenglish/pages/quiz_result_page.dart';
import 'package:easyenglish/models/quiz_models.dart';
import 'dart:math';

class WordQuizPage extends StatefulWidget {
  final String userId;
  final List<String> levels;
  final int quizCount;

  const WordQuizPage({
    super.key,
    required this.userId,
    required this.levels,
    required this.quizCount,
  });

  @override
  State<WordQuizPage> createState() => _WordQuizPageState();
}

class _WordQuizPageState extends State<WordQuizPage> {
  final RankingService _rankingService = RankingService();

  List<Word> _allWords = [];
  List<Word> _quizWords = [];
  List<WordQuizAnswer> _quizAnswers = [];

  bool _isLoading = true;
  String? _error;

  int _currentIndex = 0;
  int _correctAnswers = 0;
  String? _selectedMeaning;
  List<String>? _currentOptions;
  bool _isQuizFinished = false;
  bool _isRankingSaved = false;

  // 랭킹 데이터
  List<RankingData> _topCorrectRankings = [];
  List<RankingData> _topAccuracyRankings = [];
  RankingData? _userRanking;
  bool _isLoadingRankings = false;

  // 색상 설정
  final Color defaultBorderColor = Colors.grey.shade200;
  final Color barColor = const Color.fromARGB(255, 117, 171, 180);
  final Color nextButtonColor = const Color(0xFF6C88B7);
  final Color prevButtonColor = const Color(0xFF6C88B7);

  @override
  void initState() {
    super.initState();
    _fetchWordsAndStartQuiz();
  }

  Future<void> _fetchWordsAndStartQuiz() async {
    try {
      final fetchedData = await WordDataService().fetchWordList();

      final words = <Word>[];
      for (var level in widget.levels) {
        words.addAll(fetchedData[level] ?? []);
      }

      if (!mounted) return;

      if (words.isEmpty) {
        setState(() {
          _error = '선택된 레벨에 단어가 없습니다.';
          _isLoading = false;
        });
        return;
      }

      setState(() {
        _allWords = words;
        _quizWords = _generateQuiz();
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  List<Word> _generateQuiz() {
    final random = Random();
    final List<Word> availableWords = List.from(_allWords);
    final int count = min(widget.quizCount, availableWords.length);

    return List.generate(count, (_) {
      final index = random.nextInt(availableWords.length);
      return availableWords.removeAt(index);
    });
  }

  void _checkAnswer(String selectedMeaning) {
    setState(() => _selectedMeaning = selectedMeaning);
  }

  void _nextQuiz() {
    if (_selectedMeaning == null) return;

    final currentWord = _quizWords[_currentIndex];
    final isCorrect = _selectedMeaning == currentWord.meaning;

    _quizAnswers.add(
      WordQuizAnswer(
        word: currentWord,
        selectedAnswer: _selectedMeaning!,
        isCorrect: isCorrect,
        options: List.from(_currentOptions!),
      ),
    );

    if (isCorrect) _correctAnswers++;

    setState(() {
      _currentIndex++;
      _selectedMeaning = null;
      _currentOptions = null;
    });
  }

  void _previousQuiz() {
    if (_currentIndex == 0) return;

    setState(() {
      _currentIndex--;
      _selectedMeaning = null;
      _currentOptions = null;

      if (_quizAnswers.length > _currentIndex) {
        final removed = _quizAnswers.removeAt(_currentIndex);
        if (removed.isCorrect) _correctAnswers--;
      }
    });
  }

  void _resetQuiz() {
    setState(() {
      _currentIndex = 0;
      _correctAnswers = 0;
      _selectedMeaning = null;
      _isQuizFinished = false;
      _isRankingSaved = false;
      _currentOptions = null;
      _quizAnswers = [];
      _quizWords = _generateQuiz();
      _topCorrectRankings = [];
      _topAccuracyRankings = [];
      _userRanking = null;
    });
  }

  void _goToHome() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
          builder: (_) => const LevelSelectPage(
                userId: '',
              )),
      (route) => false,
    );
  }

  Future<void> _goToQuizResult() async {
    final userId = await _rankingService.getUserName() ?? "익명";

    if (!mounted) return;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => QuizResultPage(
          userId: userId,
          quizAnswers: _quizAnswers,
          correctAnswers: _correctAnswers,
          totalQuestions: _quizWords.length,
          levels: widget.levels,
        ),
      ),
    );
  }

  Future<void> _calculateFinalScore() async {
    _isQuizFinished = true;
    if (!_isRankingSaved) {
      await _saveRanking();
      _isRankingSaved = true;
      await _loadRankings();
    }
  }

  Future<void> _saveRanking() async {
    try {
      final userName = await _rankingService.getUserName() ?? "익명";

      final ranking = RankingData(
        userName: userName,
        correctAnswers: _correctAnswers,
        totalQuestions: _quizWords.length,
        accuracy: _correctAnswers / _quizWords.length,
        testDate: DateTime.now(),
        level: widget.levels.join(', '),
        userId: userName,
      );

      await _rankingService.addRanking(ranking);
      _userRanking = ranking;
    } catch (e) {
      debugPrint('랭킹 저장 실패: $e');
    }
  }

  Future<void> _loadRankings() async {
    setState(() => _isLoadingRankings = true);

    try {
      final allRankings = await _rankingService.getRankings();
      final userName = await _rankingService.getUserName() ?? "익명";

      // 레벨별 필터링 - 더 유연한 매칭
      final levelRankings = allRankings.where((ranking) {
        final currentLevels = widget.levels.toSet();
        final rankingLevels = ranking.level.split(', ').toSet();
        return currentLevels.intersection(rankingLevels).isNotEmpty;
      }).toList();

      // 정답 수 기준 상위 3위
      final correctRankings = List<RankingData>.from(levelRankings);
      correctRankings
          .sort((a, b) => b.correctAnswers.compareTo(a.correctAnswers));
      _topCorrectRankings = correctRankings.take(3).toList();

      // 정확도 기준 상위 3위
      final accuracyRankings = List<RankingData>.from(levelRankings);
      accuracyRankings.sort((a, b) => b.accuracy.compareTo(a.accuracy));
      _topAccuracyRankings = accuracyRankings.take(3).toList();

      // 사용자 랭킹 찾기 - null 체크 개선
      if (_userRanking == null) {
        final userRankings = levelRankings
            .where((ranking) => ranking.userName == userName)
            .toList();

        if (userRankings.isNotEmpty) {
          userRankings.sort((a, b) => b.testDate.compareTo(a.testDate));
          _userRanking = userRankings.first;
        }
      }
    } catch (e) {
      debugPrint('랭킹 로드 실패: $e');
    } finally {
      setState(() => _isLoadingRankings = false);
    }
  }

  List<String> _getMeaningOptions(Word word) {
    if (_currentOptions != null) return _currentOptions!;

    final random = Random();
    final options = <String>[word.meaning];

    final allMeanings = _allWords
        .where((w) => w.word != word.word)
        .map((w) => w.meaning)
        .toSet()
        .toList()
      ..shuffle(random);

    while (options.length < 4 && allMeanings.isNotEmpty) {
      options.add(allMeanings.removeAt(0));
    }

    if (options.length < 4) {
      final tempWords = _allWords.where((w) => w.word != word.word).toList();
      while (options.length < 4 && tempWords.isNotEmpty) {
        options.add(tempWords[random.nextInt(tempWords.length)].meaning);
      }
    }

    options.shuffle(random);
    _currentOptions = List.from(options);
    return _currentOptions!;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('오류')),
        body: Center(child: Text(_error!)),
      );
    }
    if (_quizWords.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('단어 없음')),
        body: const Center(child: Text('퀴즈를 위한 단어가 없습니다.')),
      );
    }

    if (_currentIndex >= _quizWords.length) {
      if (!_isQuizFinished) _calculateFinalScore();
      return _buildResultScreen(context);
    }

    return _buildQuizScreen(context);
  }

  Widget _buildRankingCard(
      String title, List<RankingData> rankings, String valueType) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF6C88B7),
              ),
            ),
            const SizedBox(height: 12),
            if (rankings.isEmpty)
              const Text('랭킹 데이터가 없습니다.', style: TextStyle(color: Colors.grey))
            else
              Column(
                children: rankings.asMap().entries.map((entry) {
                  final index = entry.key;
                  final ranking = entry.value;
                  final isUser = _userRanking != null &&
                      ranking.userName == _userRanking!.userName;

                  String value;
                  if (valueType == 'correct') {
                    value =
                        '${ranking.correctAnswers}/${ranking.totalQuestions}개';
                  } else {
                    value = '${(ranking.accuracy * 100).toStringAsFixed(1)}%';
                  }

                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 2),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: isUser ? Colors.blue.shade50 : null,
                      borderRadius: BorderRadius.circular(8),
                      border: isUser
                          ? Border.all(color: Colors.blue.shade200)
                          : null,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: index == 0
                                ? Colors.amber
                                : index == 1
                                    ? Colors.grey
                                    : index == 2
                                        ? Colors.brown
                                        : Colors.grey.shade300,
                          ),
                          child: Center(
                            child: Text(
                              '${index + 1}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            ranking.userName,
                            style: TextStyle(
                              fontWeight:
                                  isUser ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                        ),
                        Text(
                          value,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: isUser ? Colors.blue.shade700 : null,
                          ),
                        ),
                        if (isUser)
                          const Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: Icon(Icons.person,
                                size: 16, color: Colors.blue),
                          ),
                      ],
                    ),
                  );
                }).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultScreen(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('퀴즈 결과'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: _goToHome,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // 결과 섹션
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade200,
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text('🎉', style: TextStyle(fontSize: 60)),
                  const SizedBox(height: 20),
                  Text(
                    '총 ${_quizWords.length}문제 중 $_correctAnswers개 맞춤!',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '정확도: ${((_correctAnswers / _quizWords.length) * 100).toStringAsFixed(1)}%',
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 135,
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.analytics_outlined),
                          label: const Text('시험결과'),
                          onPressed: _goToQuizResult,
                        ),
                      ),
                      const SizedBox(width: 10),
                      SizedBox(
                        width: 135,
                        child: FilledButton.icon(
                          icon: const Icon(Icons.refresh),
                          label: const Text('다시 시작'),
                          onPressed: _resetQuiz,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // 랭킹 섹션
            if (_isLoadingRankings)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: CircularProgressIndicator()),
                ),
              )
            else ...[
              _buildRankingCard(
                '🏆 정답 수 랭킹 TOP 3',
                _topCorrectRankings,
                'correct',
              ),
              _buildRankingCard(
                '🎯 정확도 랭킹 TOP 3',
                _topAccuracyRankings,
                'accuracy',
              ),

              // 내 랭킹
              if (_userRanking != null)
                Card(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  color: Colors.blue.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '👤 내 기록',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF6C88B7),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Icon(Icons.person, color: Colors.blue),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _userRanking!.userName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                                '정답 수: ${_userRanking!.correctAnswers}/${_userRanking!.totalQuestions}개'),
                            Text(
                                '정확도: ${(_userRanking!.accuracy * 100).toStringAsFixed(1)}%'),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
            ],

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildQuizScreen(BuildContext context) {
    final currentWord = _quizWords[_currentIndex];
    final options = _getMeaningOptions(currentWord);
    final optionNumbers = ["①", "②", "③", "④"];

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.levels.join(', ')} 단어시험'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // 진행도
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('문제 ${_currentIndex + 1}/${_quizWords.length}'),
                        Text(
                          '진도: ${(((_currentIndex + 1) / _quizWords.length) * 100).toInt()}%',
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(
                      value: (_currentIndex + 1) / _quizWords.length,
                      minHeight: 6,
                      backgroundColor: Colors.grey.shade200,
                      color: barColor,
                    ),
                    const SizedBox(height: 16),

                    // 단어 카드
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 30),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 233, 227, 227),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: const Color.fromARGB(139, 238, 238, 238),
                            blurRadius: 6,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Text(currentWord.word,
                              style: const TextStyle(
                                  fontSize: 32, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 6),
                          Text('[${currentWord.pronunciation}]',
                              style: TextStyle(color: Colors.grey.shade600)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // 보기
                    Column(
                      children: options.asMap().entries.map((entry) {
                        final idx = entry.key;
                        final option = entry.value;
                        final isSelected = _selectedMeaning == option;

                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: isSelected
                                    ? Colors.green
                                    : defaultBorderColor,
                                width: 1.5),
                            color: isSelected
                                ? const Color.fromARGB(255, 232, 232, 245)
                                : Colors.grey.shade50,
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              borderRadius: BorderRadius.circular(10),
                              onTap: () => _checkAnswer(option),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 12, horizontal: 14),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                          '${optionNumbers[idx]} $option',
                                          style: TextStyle(
                                              color: isSelected
                                                  ? Colors.green.shade700
                                                  : Colors.black87,
                                              fontSize: 15,
                                              fontWeight: FontWeight.w500)),
                                    ),
                                    if (isSelected)
                                      const Icon(Icons.check_circle,
                                          color: Colors.green, size: 20),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),

                    // 이전 / 다음 버튼
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: 140,
                          height: 48,
                          child: ElevatedButton(
                            onPressed: _currentIndex > 0 ? _previousQuiz : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: prevButtonColor,
                              foregroundColor:
                                  const Color.fromARGB(255, 255, 255, 255),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.arrow_back_ios, size: 18),
                                SizedBox(width: 4),
                                Text('이전'),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 140,
                          height: 48,
                          child: ElevatedButton(
                            onPressed:
                                _selectedMeaning != null ? _nextQuiz : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: nextButtonColor,
                              foregroundColor:
                                  const Color.fromARGB(255, 255, 255, 255),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Text('다음'),
                                SizedBox(width: 4),
                                Icon(Icons.arrow_forward_ios, size: 18),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
