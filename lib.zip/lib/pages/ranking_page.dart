import 'package:flutter/material.dart';
import 'package:easyenglish/models/ranking_data.dart';
import 'package:easyenglish/services/ranking_service.dart';
import 'package:easyenglish/pages/level_select_page.dart';

class RankingPage extends StatefulWidget {
  const RankingPage({super.key, required this.userId});
  final String userId;

  // ⚠️ 'RankingPage'를 호출할 때 다음과 같이 userId를 반드시 전달해야 합니다.
  // Navigator.push(
  //   context,
  //   MaterialPageRoute(
  //     builder: (context) => const RankingPage(userId: '사용자ID_여기에_입력'),
  //   ),
  // );

  @override
  State<RankingPage> createState() => _RankingPageState();
}

class _RankingPageState extends State<RankingPage> {
  final RankingService _rankingService = RankingService();
  List<RankingData> _rankingList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRankingList();
  }

  Future<void> _loadRankingList() async {
    final list = await _rankingService.getRankings();
    list.sort((a, b) => b.accuracy.compareTo(a.accuracy));
    setState(() {
      _rankingList = list;
      _isLoading = false;
    });
  }

  Future<void> _clearRankings() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('랭킹 초기화'),
        content: const Text('정말로 모든 랭킹 기록을 초기화하시겠습니까?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('초기화'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _rankingService.clearRankings();
      _loadRankingList();
    }
  }

  String _formatDate(DateTime date) {
    return '${date.year}.${date.month}.${date.day} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('랭킹 순위', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () {
            // LevelSelectPage로 이동할 때 userId를 전달하도록 수정
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => LevelSelectPage(userId: widget.userId),
              ),
              (route) => false,
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_forever),
            onPressed: _clearRankings,
            tooltip: '랭킹 초기화',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _rankingList.isEmpty
              ? const Center(child: Text('아직 랭킹 기록이 없습니다.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _rankingList.length,
                  itemBuilder: (context, index) {
                    final ranking = _rankingList[index];
                    final rank = index + 1;
                    return Card(
                      elevation: 2,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      child: ListTile(
                        leading: Text('$rank위',
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: rank <= 3 ? Colors.amber : Colors.grey)),
                        title: Text(ranking.userName,
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                '정답: ${ranking.correctAnswers}/${ranking.totalQuestions}'),
                            Text(
                                '정확도: ${(ranking.accuracy * 100).toStringAsFixed(0)}%'),
                          ],
                        ),
                        trailing: Text(_formatDate(ranking.testDate),
                            style: const TextStyle(
                                fontSize: 12, color: Colors.grey)),
                      ),
                    );
                  }),
    );
  }
}
