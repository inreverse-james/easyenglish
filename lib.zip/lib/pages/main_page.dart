import 'package:flutter/material.dart';
import 'package:easyenglish/services/word_data_service.dart';
import 'package:easyenglish/pages/word_study_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final WordDataService _dataService = WordDataService();
  bool _isLoading = true;
  String? _error;
  List<String> _levels = [];

  @override
  void initState() {
    super.initState();
    _fetchLevels();
  }

  Future<void> _fetchLevels() async {
    try {
      final fetchedLevels = await _dataService.fetchLevels();
      if (mounted) {
        setState(() {
          _levels = fetchedLevels;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Easy English'),
          backgroundColor: const Color(0xFF6C88B7),
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Easy English'),
          backgroundColor: const Color(0xFF6C88B7),
        ),
        body: Center(
          child: Text('Error: $_error'),
        ),
      );
    }

    if (_levels.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Easy English'),
          backgroundColor: const Color(0xFF6C88B7),
        ),
        body: const Center(
          child: Text('단어 레벨을 찾을 수 없습니다.'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Easy English'),
        backgroundColor: const Color(0xFF6C88B7),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text(
              '학습할 단어 레벨을 선택하세요.',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF6C88B7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _levels.length,
                itemBuilder: (context, index) {
                  final level = _levels[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      title: Text(
                        '레벨 $level',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      trailing: const Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => WordStudyPage(
                              level: level,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
