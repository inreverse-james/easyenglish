import 'package:flutter/material.dart';
import 'package:easyenglish/pages/settings_page.dart';
import 'package:easyenglish/pages/word_quiz_page.dart';
import 'package:easyenglish/pages/word_study_page.dart';
import 'package:easyenglish/pages/ranking_page.dart';
import '../services/word_data_service.dart';

/// 📌 개별 레벨 선택 버튼 위젯
class LevelSelectButton extends StatelessWidget {
  final String userId;
  final String levelName;
  final String description;
  final VoidCallback onTap;

  const LevelSelectButton({
    super.key,
    required this.userId,
    required this.levelName,
    required this.description,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 250,
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey.shade300,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    levelName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios,
              color: Color(0xFF6C88B7),
              size: 14,
            ),
          ],
        ),
      ),
    );
  }
}

/// 📌 레벨 선택 페이지
class LevelSelectPage extends StatefulWidget {
  final String userId;

  const LevelSelectPage({super.key, required this.userId});

  @override
  State<LevelSelectPage> createState() => _LevelSelectPageState();
}

class _LevelSelectPageState extends State<LevelSelectPage> {
  // 🔧 수정: WordDataService 사용 (간단한 CSV 방식)
  final WordDataService _wordDataService = WordDataService();

  List<String> levels = [];
  final List<String> levelDescriptions = [
    'Beginner Level',
    'Elementary Level',
    'Intermediate Level',
    'Advanced Level',
    'Expert Level',
  ];

  String? selectedQuizLevel;
  int selectedQuizCount = 10;
  final List<int> quizCounts = [10, 20, 30, 40, 50];

  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchLevels();
  }

  /// 구글시트에서 레벨 목록 가져오기
  Future<void> _fetchLevels() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // 🔧 수정: API 서비스 사용하여 레벨 목록 가져오기
      final availableLevels = await _wordDataService.fetchLevels();
      if (mounted) {
        setState(() {
          levels = availableLevels;
          // 레벨 순서 정렬
          final sortedLevels = ['입문', '초급', '중급', '상급', '최상급'];
          levels.sort((a, b) {
            int indexA = sortedLevels.indexOf(a);
            int indexB = sortedLevels.indexOf(b);
            if (indexA == -1) indexA = sortedLevels.length;
            if (indexB == -1) indexB = sortedLevels.length;
            return indexA.compareTo(indexB);
          });
          _isLoading = false;
          // 첫 번째 레벨을 기본값으로 설정
          if (levels.isNotEmpty) {
            selectedQuizLevel = levels.first;
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    const double boxWidth = 250;
    const double dropdownWidth = 120;
    final bool isQuizButtonEnabled = selectedQuizLevel != null;

    /// 로딩중
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    /// 오류 발생
    if (_error != null) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.error_outline,
                  color: Colors.red,
                  size: 50,
                ),
                const SizedBox(height: 12),
                const Text(
                  '데이터를 불러오는 데 실패했습니다.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '오류: $_error',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: _fetchLevels,
                  icon: const Icon(Icons.refresh),
                  label: const Text('다시 시도'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6C88B7),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    /// 정상 화면
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FB),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Text(
          'English Study',
          style: TextStyle(
            color: Colors.black,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: -0.5,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.black),
            onPressed: () {
              // 🔧 수정: userId를 올바르게 전달
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => SettingsPage(
                    userId: widget.userId,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 12),
            const Text(
              'ENGLISH Words',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 68, 111, 187),
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Choose your level to start learning',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 70, 199, 65),
                fontWeight: FontWeight.w600,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 16),

            /// 단어 공부 버튼 리스트
            Column(
              children: List.generate(levels.length, (index) {
                final levelName = levels[index];
                final levelDescription = (index < levelDescriptions.length)
                    ? levelDescriptions[index]
                    : 'Custom Level ${index - 4}';
                return LevelSelectButton(
                  userId: widget.userId,
                  levelName: levelName,
                  description: levelDescription,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => WordStudyPage(
                          level: levelName,
                        ),
                      ),
                    );
                  },
                );
              }),
            ),

            const SizedBox(height: 8),
            Divider(thickness: 1, color: Colors.grey.shade300),
            const SizedBox(height: 8),

            /// 퀴즈 옵션 선택 (레벨 + 문제수)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // 문제 수준 선택
                Container(
                  width: dropdownWidth,
                  height: 32,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.grey.shade300,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(6),
                    color: Colors.white,
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: selectedQuizLevel,
                      hint: const Text(
                        '수준 선택',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                      isExpanded: true,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black,
                      ),
                      items: levels
                          .map((level) => DropdownMenuItem(
                                value: level,
                                child: Text(level),
                              ))
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => selectedQuizLevel = value);
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // 문제 수 선택
                Container(
                  width: dropdownWidth,
                  height: 32,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.grey.shade300,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(6),
                    color: Colors.white,
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      value: selectedQuizCount,
                      isExpanded: true,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black,
                      ),
                      items: quizCounts
                          .map((count) => DropdownMenuItem(
                                value: count,
                                child: Text('$count 문제'),
                              ))
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => selectedQuizCount = value);
                        }
                      },
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            /// 단어 시험 시작 버튼
            SizedBox(
              width: boxWidth,
              height: 48,
              child: ElevatedButton(
                onPressed: isQuizButtonEnabled
                    ? () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => WordQuizPage(
                              userId: widget.userId,
                              levels: [selectedQuizLevel!],
                              quizCount: selectedQuizCount,
                            ),
                          ),
                        );
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isQuizButtonEnabled
                      ? const Color(0xFF6C88B7)
                      : Colors.grey.shade300,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  '단어 시험 시작 ✏️',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),

            /// 단어 시험 랭킹 보기 버튼
            SizedBox(
              width: boxWidth,
              height: 48,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => RankingPage(userId: widget.userId),
                    ),
                  );
                },
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF6C88B7)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  '단어 시험 랭킹 보기 🏆',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF6C88B7),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
