import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:easyenglish/services/firebase_service.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _firebaseService = FirebaseService();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // 로그인 상태 확인 (익명 사용자 제외)
  void _checkLoginStatus() {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null && !currentUser.isAnonymous) {
      _navigateToNextPage();
    }
  }

  void _navigateToNextPage() {
    if (mounted) {
      // 라우트 이름이 '/level_select'로 등록되어 있어야 합니다.
      Navigator.of(context).pushReplacementNamed('/level_select');
    }
  }

  // 1. 이메일 회원가입
  Future<void> _signUpWithEmail() async {
    if (!_validateInputs()) return;

    setState(() => _isLoading = true);
    try {
      final user = await _firebaseService.signUpWithEmail(
        _emailController.text.trim(),
        _passwordController.text.trim(),
      );

      if (user != null) {
        await user.sendEmailVerification();
        _showSuccessMessage('회원가입 완료! 이메일 인증을 확인해주세요.');
        _navigateToNextPage();
      }
    } on FirebaseAuthException catch (e) {
      _showErrorMessage(_getFirebaseErrorMessage(e.code));
    } catch (e) {
      _showErrorMessage('알 수 없는 오류가 발생했습니다.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // 2. 게스트 로그인 (익명 로그인)
  Future<void> _continueAsGuest() async {
    setState(() => _isLoading = true);
    try {
      final userCredential = await FirebaseAuth.instance.signInAnonymously();
      if (userCredential.user != null) {
        _showSuccessMessage('게스트 모드로 시작합니다.');
        _navigateToNextPage();
      }
    } catch (e) {
      _showErrorMessage('게스트 모드 진입에 실패했습니다.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // 3. 구글 로그인
  Future<void> _signInWithGoogle() async {
    setState(() => _isLoading = true);
    try {
      final user = await _firebaseService.signInWithGoogle();
      if (user != null) {
        _showSuccessMessage('구글 로그인 성공!');
        _navigateToNextPage();
      }
    } catch (e) {
      _showErrorMessage('구글 로그인 중 오류가 발생했습니다.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // 입력값 검증
  bool _validateInputs() {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || !email.contains('@')) {
      _showErrorMessage('올바른 이메일을 입력해주세요.');
      return false;
    }
    if (password.length < 6) {
      _showErrorMessage('비밀번호는 최소 6자 이상이어야 합니다.');
      return false;
    }
    return true;
  }

  // 에러 메시지 번역
  String _getFirebaseErrorMessage(String errorCode) {
    switch (errorCode) {
      case 'email-already-in-use':
        return '이미 사용 중인 이메일입니다.';
      case 'weak-password':
        return '비밀번호가 너무 취약합니다.';
      case 'invalid-email':
        return '유효하지 않은 이메일 형식입니다.';
      default:
        return '회원가입 실패: $errorCode';
    }
  }

  void _showErrorMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void _showSuccessMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('시작하기'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('환영합니다!',
                    style:
                        TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('계정을 생성하거나 게스트로 체험해보세요.',
                    style: TextStyle(fontSize: 16, color: Colors.grey)),
                const SizedBox(height: 32),
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: '이메일',
                    prefixIcon: const Icon(Icons.email_outlined),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: '비밀번호',
                    prefixIcon: const Icon(Icons.lock_outline),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 32),
                if (_isLoading)
                  const Center(child: CircularProgressIndicator())
                else ...[
                  _buildButton(
                    label: '이메일로 회원가입',
                    onPressed: _signUpWithEmail,
                    color: const Color(0xFF6C88B7),
                    textColor: Colors.white,
                  ),
                  const SizedBox(height: 12),
                  _buildButton(
                    label: '게스트로 시작하기',
                    onPressed: _continueAsGuest,
                    color: Colors.white,
                    textColor: const Color(0xFF6C88B7),
                    isOutlined: true,
                  ),
                  const SizedBox(height: 24),
                  const Row(
                    children: [
                      Expanded(child: Divider()),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          child: Text('또는')),
                      Expanded(child: Divider()),
                    ],
                  ),
                  const SizedBox(height: 24),
                  _buildButton(
                    label: '구글로 계속하기',
                    onPressed: _signInWithGoogle,
                    color: Colors.white,
                    textColor: Colors.black87,
                    icon: Icons.g_mobiledata,
                    isOutlined: true,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // 버튼 공통 위젯
  Widget _buildButton({
    required String label,
    required VoidCallback onPressed,
    required Color color,
    required Color textColor,
    IconData? icon,
    bool isOutlined = false,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: isOutlined
          ? OutlinedButton.icon(
              icon:
                  icon != null ? Icon(icon, size: 28) : const SizedBox.shrink(),
              label: Text(label,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(
                foregroundColor: textColor,
                side: BorderSide(
                    color: isOutlined && color == Colors.white
                        ? Colors.grey.shade300
                        : color),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            )
          : ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                foregroundColor: textColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: Text(label,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ),
    );
  }
}
