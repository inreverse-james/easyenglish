import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_sign_in/google_sign_in.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required String userId});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  // 프로필 정보
  String _organization = '';

  // 아바타 선택
  int _selectedAvatarIndex = 0;
  final List<String> _defaultAvatars = [
    'assets/avatars/avatar1.png',
    'assets/avatars/avatar2.png',
    'assets/avatars/avatar3.png',
    'assets/avatars/avatar4.png',
    'assets/avatars/avatar5.png',
    'assets/avatars/avatar6.png',
    'assets/avatars/avatar7.png',
    'assets/avatars/avatar8.png',
    'assets/avatars/avatar9.png',
    'assets/avatars/avatar10.png',
  ];

  // 비동기 작업의 상태를 추적하기 위한 Future 객체
  late Future<void> _loadSettingsFuture;

  @override
  void initState() {
    super.initState();
    debugPrint('SettingsPage: initState() 호출');
    _loadSettingsFuture = _loadSettings();
  }

  Future<void> _loadSettings() async {
    debugPrint('SettingsPage: _loadSettings() 시작');
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _selectedAvatarIndex = prefs.getInt('selectedAvatarIndex') ?? 0;
        _organization = prefs.getString('organization') ?? '';
      });
      debugPrint('SettingsPage: _loadSettings() 완료');
    } catch (e) {
      debugPrint('SettingsPage: _loadSettings() 실패: $e');
      rethrow;
    }
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('selectedAvatarIndex', _selectedAvatarIndex);
    await prefs.setString('organization', _organization);
  }

  String _getDisplayName(User? user) {
    if (user == null || user.isAnonymous) return "게스트 사용자";
    final dn = user.displayName;
    if (dn != null && dn.isNotEmpty) return dn;
    final em = user.email;
    if (em != null && em.isNotEmpty) return em.split('@')[0];
    return "사용자";
  }

  String _getUserId(User? user) {
    if (user == null) return "게스트";
    if (user.isAnonymous) return "Guest ID: ${user.uid}";
    return "사용자 ID: ${user.uid}";
  }

  // 프로필 편집 다이얼로그
  void _showProfileEditDialog() {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final nicknameController =
        TextEditingController(text: user.displayName ?? '');
    final organizationController = TextEditingController(text: _organization);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('프로필 편집'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nicknameController,
              decoration: const InputDecoration(
                labelText: '닉네임',
                border: OutlineInputBorder(),
                hintText: '사용할 닉네임을 입력하세요',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: organizationController,
              decoration: const InputDecoration(
                labelText: '소속',
                border: OutlineInputBorder(),
                hintText: '소속을 입력하세요 (예: 회사명, 학교명 등)',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('취소'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                final newNickname = nicknameController.text.trim();
                if (newNickname.isNotEmpty) {
                  await user.updateDisplayName(newNickname);
                  await user.reload();
                  setState(() {});
                }

                setState(() {
                  _organization = organizationController.text.trim();
                });
                await _saveSettings();

                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('프로필이 업데이트되었습니다.')),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('프로필 업데이트 실패: $e')),
                  );
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6C88B7),
              foregroundColor: Colors.white,
            ),
            child: const Text('저장'),
          ),
        ],
      ),
    );
  }

  // 게스트로 시작하기
  Future<void> _signInAnonymously() async {
    try {
      await FirebaseAuth.instance.signInAnonymously();
      if (mounted) {
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('게스트로 로그인했습니다.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('게스트 로그인 실패: $e')),
        );
      }
    }
  }

  // 구글 로그인 / 계정 연동
  // - 게스트(익명) 상태라면 기존 데이터를 유지한 채 구글 계정으로 "연동"합니다.
  // - 이미 구글 계정으로 로그인된 상태라면 다른 구글 계정으로 전환합니다.
  Future<void> _signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      if (googleUser == null) {
        return;
      }

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final currentUser = FirebaseAuth.instance.currentUser;

      if (currentUser != null && currentUser.isAnonymous) {
        try {
          await currentUser.linkWithCredential(credential);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Google 계정과 연동되었습니다! 기존 데이터는 유지됩니다.')),
            );
          }
        } on FirebaseAuthException catch (e) {
          if (e.code == 'credential-already-in-use') {
            await FirebaseAuth.instance.signInWithCredential(credential);
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('이미 사용 중인 Google 계정이라 해당 계정으로 로그인했습니다.')),
              );
            }
          } else {
            rethrow;
          }
        }
      } else {
        await FirebaseAuth.instance.signInWithCredential(credential);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('구글 계정으로 로그인했습니다!')),
          );
        }
      }

      if (mounted) setState(() {});
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('로그인 실패: ${e.message}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('알 수 없는 오류 발생: $e')),
        );
      }
    }
  }

  // 로그아웃
  Future<void> _signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
      await GoogleSignIn().signOut();
      if (mounted) {
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('로그아웃했습니다.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('로그아웃 실패: $e')),
        );
      }
    }
  }

  // 아바타 선택 다이얼로그
  void _showAvatarSelectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('아바타 선택'),
        content: SizedBox(
          width: double.maxFinite,
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: _defaultAvatars.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedAvatarIndex = index;
                  });
                  _saveSettings();
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('아바타가 변경되었습니다.')),
                  );
                },
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CircleAvatar(
                      radius: 40,
                      backgroundImage: AssetImage(_defaultAvatars[index]),
                    ),
                    if (_selectedAvatarIndex == index)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF6C88B7),
                              width: 3,
                            ),
                          ),
                        ),
                      ),
                    if (_selectedAvatarIndex == index)
                      const Icon(
                        Icons.check_circle,
                        color: Color(0xFF6C88B7),
                        size: 24,
                      ),
                  ],
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('취소'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _loadSettingsFuture,
      builder: (context, snapshot) {
        debugPrint(
            'FutureBuilder: ConnectionState -> ${snapshot.connectionState}');

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('설정을 불러오는 중입니다...'),
                ],
              ),
            ),
          );
        }

        if (snapshot.hasError) {
          return Scaffold(
            appBar: AppBar(
              title: const Text('설정'),
              backgroundColor: const Color(0xFF6C88B7),
              foregroundColor: Colors.white,
            ),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error, color: Colors.red, size: 60),
                  const SizedBox(height: 16),
                  const Text(
                    '설정 로딩에 실패했습니다.',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '오류: ${snapshot.error}',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
          );
        }

        final User? user = FirebaseAuth.instance.currentUser;
        final bool isGoogleUser = user != null && !user.isAnonymous;
        final String? photoUrl = user?.photoURL;

        ImageProvider profileImage;
        if (photoUrl != null && photoUrl.isNotEmpty) {
          profileImage = NetworkImage(photoUrl);
        } else {
          profileImage = AssetImage(_defaultAvatars[_selectedAvatarIndex]);
        }

        return Scaffold(
          appBar: AppBar(
            title: const Text('설정'),
            backgroundColor: const Color(0xFF6C88B7),
            foregroundColor: Colors.white,
          ),
          body: Padding(
            padding: const EdgeInsets.all(24.0),
            child: ListView(
              children: [
                const SizedBox(height: 16),

                // 프로필
                Center(
                  child: GestureDetector(
                    onTap: _showAvatarSelectionDialog,
                    child: Stack(
                      children: [
                        CircleAvatar(
                          radius: 50,
                          backgroundImage: profileImage,
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Color(0xFF6C88B7),
                              shape: BoxShape.circle,
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(
                                Icons.edit,
                                size: 16,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // 닉네임 표시 및 편집 버튼
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _getDisplayName(user),
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      if (user != null) ...[
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: _showProfileEditDialog,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: Colors.grey[100],
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(
                                  color: Colors.grey[300]!, width: 0.5),
                            ),
                            child: const Icon(
                              Icons.edit,
                              size: 16,
                              color: Color(0xFF6C88B7),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // 소속 정보 표시 (있을 경우에만)
                if (_organization.isNotEmpty)
                  Center(
                    child: Text(
                      _organization,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                if (_organization.isNotEmpty) const SizedBox(height: 8),

                // 사용자 ID 표시
                Center(
                  child: SelectableText(
                    _getUserId(user),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // 프로필 편집 버튼 (로그인된 사용자에게만 표시)
                if (user != null) ...[
                  ElevatedButton.icon(
                    onPressed: _showProfileEditDialog,
                    icon: const Icon(Icons.person),
                    label: const Text('프로필 편집'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[50],
                      foregroundColor: const Color(0xFF6C88B7),
                      elevation: 0,
                      side:
                          const BorderSide(color: Color(0xFF6C88B7), width: 1),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                // 로그인 관련 버튼들 (구글 / 게스트만 표시)
                if (user == null) ...[
                  // 로그인되지 않은 상태
                  ElevatedButton.icon(
                    onPressed: _signInAnonymously,
                    icon: const Icon(Icons.person),
                    label: const Text('게스트로 시작하기'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[600],
                      foregroundColor: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _signInWithGoogle,
                    icon: Image.asset('assets/images/google_logo.png',
                        height: 24, width: 24),
                    label: const Text('Google 계정으로 로그인'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      side: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                ] else if (!isGoogleUser) ...[
                  // 게스트로 로그인된 상태 -> 구글 계정 연동 유도
                  ElevatedButton.icon(
                    onPressed: _signInWithGoogle,
                    icon: Image.asset('assets/images/google_logo.png',
                        height: 24, width: 24),
                    label: const Text('Google 계정과 연동하기'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      side: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _signOut,
                    icon: const Icon(Icons.logout),
                    label: const Text('로그아웃'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ] else ...[
                  // 구글 계정으로 로그인된 상태
                  ElevatedButton.icon(
                    onPressed: _signInWithGoogle,
                    icon: Image.asset('assets/images/google_logo.png',
                        height: 24, width: 24),
                    label: const Text('다른 Google 계정으로 전환'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      side: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _signOut,
                    icon: const Icon(Icons.logout),
                    label: const Text('로그아웃'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],

                const Divider(height: 32),
              ],
            ),
          ),
        );
      },
    );
  }
}